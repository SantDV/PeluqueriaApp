﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeluqueriaApp
{
    public static class AppInfo
    {
        public const string Version = "1.2.1";
    }

}
